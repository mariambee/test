<form action="quote.php" method="post">
    <fieldset>
        <!-- create symbol field -->
        <div class="form-group">
            <input autocomplete="off" autofocus class="form-control" name="symbol" placeholder="Stock Symbol" type="text"/>
        </div>
        <!-- create button -->
        <div class="form-group">
            <button class="btn btn-default" type="submit">Search</button>
        </div>
    </fieldset>
</form>

